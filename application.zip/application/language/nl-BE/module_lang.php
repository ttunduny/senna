<?php 

$lang["module_config"] = "Configuratie";
$lang["module_config_desc"] = "Globale configuratie aanpassen";
$lang["module_customers"] = "Klanten";
$lang["module_customers_desc"] = "Zoek, bewerk, verwijder en voeg klanten toe";
$lang["module_employees"] = "Werknemers";
$lang["module_employees_desc"] = "Zoek, bewerk, verwijder en voeg werknemers toe";
$lang["module_giftcards"] = "Cadeaubons";
$lang["module_giftcards_desc"] = "Zoek, bewerk, verwijder en voeg cadeaubons toe";
$lang["module_home"] = "Home";
$lang["module_item_kits"] = "Productsets";
$lang["module_item_kits_desc"] = "Zoek, bewerk, verwijder en voeg productsets toe";
$lang["module_items"] = "Producten";
$lang["module_items_desc"] = "Zoek, bewerk, verwijder en voeg producten toe";
$lang["module_receivings"] = "Orders";
$lang["module_receivings_desc"] = "Verwerk binnenkomende orders";
$lang["module_reports"] = "Rapporten";
$lang["module_reports_desc"] = "Toon en genereer rapporten";
$lang["module_sales"] = "Kassa";
$lang["module_sales_desc"] = "Verwerk aankopen en retours";
$lang["module_suppliers"] = "Leveranciers";
$lang["module_suppliers_desc"] = "Zoek, bewerk, verwijder en voeg leveranciers toe";

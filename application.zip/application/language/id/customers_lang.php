<?php 

$lang["customers_account_number"] = "No.Pelanggan";
$lang["customers_account_number_duplicate"] = "This account number is already present in the database";
$lang["customers_basic_information"] = "Informasi Pelanggan";
$lang["customers_cannot_be_deleted"] = "pelanggan terpilih tidak bisa dihapus. satu atau lebih dari pelanggan yang dipilih memiliki penjualan.";
$lang["customers_company_name"] = "Company Name";
$lang["customers_confirm_delete"] = "Apakah Anda yakin ingin menghapus pelanggan yang dipilih?";
$lang["customers_customer"] = "Pelanggan";
$lang["customers_error_adding_updating"] = "Menambah / Memperbarui Pelanggan Salah";
$lang["customers_new"] = "Pelanggan Baru";
$lang["customers_none_selected"] = "Anda belum memilih pelanggan untuk dihapus";
$lang["customers_one_or_multiple"] = "pelanggan";
$lang["customers_successful_adding"] = "Anda telah berhasil menambah pelanggan";
$lang["customers_successful_deleted"] = "Anda telah berhasil menghapus pelanggan";
$lang["customers_successful_updating"] = "Anda telah berhasil memperbarui pelanggan";
$lang["customers_taxable"] = "Dapat dikenakan pajak";
$lang["customers_update"] = "Ubah Pelanggan";
$lang["customers_import_items_excel"] = "Import customers from Excel sheet";

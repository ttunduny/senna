<?php 

$lang["item_kits_add_item"] = "Tambah Item Barang";
$lang["item_kits_cannot_be_deleted"] = "Item Paket tidak dapat dihapus";
$lang["item_kits_confirm_delete"] = "Apakah Anda yakin ingin menghapus Item Paket dipilih?";
$lang["item_kits_description"] = "Deskripsi Item Paket";
$lang["item_kits_error_adding_updating"] = "Tambah/Ubah Item Paket tidak berhasil";
$lang["item_kits_info"] = "Item Paket Info";
$lang["item_kits_item"] = "Item Barang";
$lang["item_kits_items"] = "Item Barang";
$lang["item_kits_kit"] = "Kit Id";
$lang["item_kits_name"] = "Nama Item Paket";
$lang["item_kits_new"] = "Item Paket Baru";
$lang["item_kits_no_item_kits_to_display"] = "Tidak ada Item Paket yang ditampilkan";
$lang["item_kits_none_selected"] = "Anda belum memilih satupun Item Paket";
$lang["item_kits_one_or_multiple"] = "Item Paket";
$lang["item_kits_quantity"] = "Jumlah";
$lang["item_kits_successful_adding"] = "Item Paket Baru berhasil ditambahkan";
$lang["item_kits_successful_deleted"] = "Item Paket berhasil dihapus";
$lang["item_kits_successful_updating"] = "Item Paket berhasil dirubah";
$lang["item_kits_update"] = "Ubah Item Paket";

<?php 

$lang["login_go"] = "Lancer";
$lang["login_invalid_username_and_password"] = "Entrée invalide";
$lang["login_login"] = "Login";
$lang["login_password"] = "Mot de passe";
$lang["login_username"] = "Nom d\'utilisateur";
$lang["login_welcome_message"] = "Bienvenue au Système Open Source Point of Sale. Pour continuer, veuiller entrer votre nom d\'utilisateur et votre mot de passe ci-dessous.";

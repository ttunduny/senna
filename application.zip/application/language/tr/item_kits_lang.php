<?php 

$lang["item_kits_add_item"] = "Ürün Ekle";
$lang["item_kits_cannot_be_deleted"] = "Ürün seti silinemedi";
$lang["item_kits_confirm_delete"] = "Seçili ürün setini silmek istediğinize emin misiniz?";
$lang["item_kits_description"] = "Ürün Seti Tanımı";
$lang["item_kits_error_adding_updating"] = "Ürün seti ekleme/güncelleme hatası";
$lang["item_kits_info"] = "Ürün Seti Bilgisi";
$lang["item_kits_item"] = "Ürün";
$lang["item_kits_items"] = "Ürünler";
$lang["item_kits_kit"] = "Kit Id";
$lang["item_kits_name"] = "Ürün Seti İsmi";
$lang["item_kits_new"] = "Yeni Ürün Seti";
$lang["item_kits_no_item_kits_to_display"] = "Gösterecek ürün seti yok";
$lang["item_kits_none_selected"] = "Ürün seti seçmediniz";
$lang["item_kits_one_or_multiple"] = "Ürün Seti";
$lang["item_kits_quantity"] = "Adet";
$lang["item_kits_successful_adding"] = "Ürün seti eklendi";
$lang["item_kits_successful_deleted"] = "Silme başarılı";
$lang["item_kits_successful_updating"] = "Ürün seti güncellendi";
$lang["item_kits_update"] = "Ürün Setini Güncelle";

<?php 

$lang["error_no_permission_module"] = "Bu modüle erişim yetkiniz yok";
$lang["error_unknown"] = "bilinmeyen";

<?php 

$lang["login_go"] = "登入";
$lang["login_invalid_username_and_password"] = "錯誤的帳號或密碼";
$lang["login_login"] = "登入";
$lang["login_password"] = "密碼";
$lang["login_username"] = "帳號";
$lang["login_welcome_message"] = "歡迎使用Master6進銷存。若要繼續，請使用您的帳號和密碼登錄。";

		</div>
	</div>

	<div id="footer">
		<?php echo $this->lang->line('common_you_are_using_ospos'); ?>
		<?php echo $this->config->item('application_version'); ?>.
	</div>
</body>
</html>